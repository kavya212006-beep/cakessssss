(function () {
  const keys = {
    cart: 'sweet_delights_cart',
    wishlist: 'sweet_delights_wishlist',
    recent: 'sweet_delights_recent',
    orders: 'sweet_delights_orders',
    coupon: 'sweet_delights_coupon'
  };

  const coupons = {
    SWEET15: { label: '15% off', discount: 0.15 },
    SWEET10: { label: '10% off', discount: 0.1 },
    DELIGHT20: { label: '20% off', discount: 0.2 }
  };

  function read(key, fallback) {
    try {
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : fallback;
    } catch {
      return fallback;
    }
  }

  function write(key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch {
      return false;
    }
    return true;
  }

  function getCart() { return read(keys.cart, []); }
  function setCart(cart) { write(keys.cart, cart); }
  function getWishlist() { return read(keys.wishlist, []); }
  function setWishlist(items) { write(keys.wishlist, items); }
  function getRecent() { return read(keys.recent, []); }
  function setRecent(items) { write(keys.recent, items.slice(0, 8)); }
  function getOrders() { return read(keys.orders, []); }
  function setOrders(items) { write(keys.orders, items); }
  function getCoupon() { return (read(keys.coupon, '') || '').toUpperCase(); }
  function setCoupon(code) { write(keys.coupon, String(code || '').toUpperCase()); }

  function itemKey(product, options = {}) {
    return `${product.slug}-${JSON.stringify(options)}`;
  }

  function addToCart(product, quantity = 1, options = {}) {
    const cart = getCart();
    const key = itemKey(product, options);
    const existing = cart.find((item) => item.key === key);
    if (existing) {
      existing.quantity += quantity;
    } else {
      cart.push({ key, id: product.id, slug: product.slug, name: product.name, image: product.images[0], price: Number(options.final ?? product.price), basePrice: Number(product.price), quantity, category: product.category, options });
    }
    setCart(cart);
    return cart;
  }

  function updateCartItem(key, quantity) {
    const cart = getCart().map((item) => item.key === key ? { ...item, quantity: Math.max(1, quantity) } : item);
    setCart(cart);
    return cart;
  }

  function removeCartItem(key) {
    const cart = getCart().filter((item) => item.key !== key);
    setCart(cart);
    return cart;
  }

  function clearCart() { setCart([]); setCoupon(''); }

  function isWishlisted(slug) {
    return getWishlist().includes(slug);
  }

  function toggleWishlist(slug) {
    const wishlist = getWishlist();
    const index = wishlist.indexOf(slug);
    if (index >= 0) wishlist.splice(index, 1); else wishlist.unshift(slug);
    setWishlist(wishlist);
    return wishlist;
  }

  function addRecent(product) {
    if (!product) return;
    const recent = getRecent().filter((slug) => slug !== product.slug);
    recent.unshift(product.slug);
    setRecent(recent);
  }

  function getAppliedCoupon(code) {
    const normalized = String(code || '').toUpperCase();
    return coupons[normalized] || null;
  }

  function getCartTotals(cart = getCart(), couponCode = getCoupon()) {
    const subtotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
    const coupon = getAppliedCoupon(couponCode);
    const discount = coupon ? subtotal * coupon.discount : 0;
    const delivery = subtotal > 120 ? 0 : cart.length ? 12 : 0;
    const taxable = Math.max(0, subtotal - discount + delivery);
    const tax = taxable * 0.085;
    const total = taxable + tax;
    return { subtotal, discount, delivery, tax, total, coupon };
  }

  function createOrderFromCart(details = {}) {
    const cart = getCart();
    if (!cart.length) return null;
    const totals = getCartTotals(cart, details.couponCode || getCoupon());
    const order = {
      id: `SD-${Date.now().toString(36).toUpperCase()}`,
      createdAt: new Date().toISOString(),
      status: 'received',
      statusIndex: 0,
      items: cart,
      totals,
      customer: details.customer || {},
      paymentMethod: details.paymentMethod || 'stripe',
      shippingAddress: details.shippingAddress || '',
      notes: details.notes || '',
      trackingCode: `TRK-${Math.random().toString(36).slice(2, 8).toUpperCase()}`
    };
    const orders = getOrders();
    orders.unshift(order);
    setOrders(orders);
    clearCart();
    return order;
  }

  function getCartCount() {
    return getCart().reduce((sum, item) => sum + item.quantity, 0);
  }

  function seedDemoOrder() {
    if (getOrders().length || !window.SweetDelightsData?.products?.length) return;
    const product = window.SweetDelightsData.products[0];
    const subtotal = product.price;
    const delivery = 12;
    const tax = (subtotal + delivery) * 0.085;
    setOrders([
      {
        id: 'SD-DEMO1',
        createdAt: new Date(Date.now() - 86400000).toISOString(),
        status: 'preparing',
        statusIndex: 1,
        items: [{ key: `${product.slug}-demo`, id: product.id, slug: product.slug, name: product.name, image: product.images[0], price: product.price, quantity: 1, category: product.category, options: {} }],
        totals: { subtotal, discount: 0, delivery, tax, total: subtotal + delivery + tax, coupon: null },
        customer: { name: 'Sophia Bennett', email: 'sophia@sweetdelights.com', phone: '555-240-2025' },
        paymentMethod: 'stripe',
        shippingAddress: '88 Velvet Avenue, New York',
        notes: 'Seeded demo order',
        trackingCode: 'TRK-DEMO1'
      }
    ]);
  }

  window.SweetDelightsStore = {
    keys, coupons, read, write, getCart, setCart, getWishlist, setWishlist, getRecent, setRecent, getOrders, setOrders,
    getCoupon, setCoupon, getCartTotals, addToCart, updateCartItem, removeCartItem, clearCart, toggleWishlist, isWishlisted,
    addRecent, createOrderFromCart, getCartCount, getAppliedCoupon
  };

  seedDemoOrder();
})();
