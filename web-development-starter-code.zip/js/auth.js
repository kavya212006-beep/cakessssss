(function () {
  const keyUsers = 'sweet_delights_users';
  const keySession = 'sweet_delights_session';

  async function sha256(text) {
    if (!crypto?.subtle) return `fallback-${text}`;
    const bytes = new TextEncoder().encode(text);
    const hash = await crypto.subtle.digest('SHA-256', bytes);
    return Array.from(new Uint8Array(hash)).map((value) => value.toString(16).padStart(2, '0')).join('');
  }

  function read(key, fallback) {
    try {
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : fallback;
    } catch {
      return fallback;
    }
  }

  function write(key, value) {
    try { localStorage.setItem(key, JSON.stringify(value)); } catch {}
  }

  async function ensureDemoUser() {
    const users = read(keyUsers, []);
    if (users.length) return users;
    const passwordHash = await sha256('Sweet123!');
    users.push({ id: 'u-001', name: 'Sophia Bennett', email: 'sophia@sweetdelights.com', passwordHash, role: 'customer', addresses: ['88 Velvet Avenue, New York'], wishlist: [], createdAt: new Date().toISOString() });
    write(keyUsers, users);
    return users;
  }

  async function registerUser({ name, email, password }) {
    const users = await ensureDemoUser();
    if (users.some((user) => user.email.toLowerCase() === email.toLowerCase())) {
      throw new Error('Email already exists');
    }
    const user = { id: `u-${Date.now()}`, name, email, passwordHash: await sha256(password), role: 'customer', addresses: [], wishlist: [], createdAt: new Date().toISOString() };
    users.unshift(user);
    write(keyUsers, users);
    write(keySession, { id: user.id, email: user.email });
    return user;
  }

  async function loginUser({ email, password }) {
    const users = await ensureDemoUser();
    const user = users.find((entry) => entry.email.toLowerCase() === email.toLowerCase());
    if (!user) throw new Error('Account not found');
    const passwordHash = await sha256(password);
    if (passwordHash !== user.passwordHash) throw new Error('Invalid password');
    write(keySession, { id: user.id, email: user.email });
    return user;
  }

  function getCurrentUser() {
    const session = read(keySession, null);
    if (!session) return null;
    const users = read(keyUsers, []);
    return users.find((entry) => entry.id === session.id) || null;
  }

  function updateCurrentUser(updates) {
    const session = read(keySession, null);
    if (!session) return null;
    const users = read(keyUsers, []);
    const index = users.findIndex((entry) => entry.id === session.id);
    if (index < 0) return null;
    users[index] = { ...users[index], ...updates };
    write(keyUsers, users);
    return users[index];
  }

  function logoutUser() {
    localStorage.removeItem(keySession);
  }

  function forgotPassword(email) {
    return `A reset email would be sent to ${email}.`;
  }

  window.SweetDelightsAuth = { ensureDemoUser, registerUser, loginUser, getCurrentUser, updateCurrentUser, logoutUser, forgotPassword, sha256 };
})();
