(function () {
  const currency = new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 });

  const images = {
    velvet: 'https://images.unsplash.com/photo-1551024601-bec78aea704b?auto=format&fit=crop&w=1200&q=80',
    wedding: 'https://images.unsplash.com/photo-1464349095431-e9a21285b5f3?auto=format&fit=crop&w=1200&q=80',
    truffle: 'https://images.unsplash.com/photo-1602351447937-745cb720612f?auto=format&fit=crop&w=1200&q=80',
    fruit: 'https://images.unsplash.com/photo-1519869325930-281384150729?auto=format&fit=crop&w=1200&q=80',
    designer: 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=1200&q=80',
    pastry: 'https://images.unsplash.com/photo-1486427944299-d1955d23e34d?auto=format&fit=crop&w=1200&q=80'
  };

  const products = [
    { id: 'p-01', slug: 'velvet-rose-birthday', name: 'Velvet Rose Birthday Cake', category: 'Birthday Cakes', price: 78, rating: 4.9, reviews: 128, featured: true, bestseller: true, badge: 'Signature', availability: 'In stock', delivery: 'Same day', description: 'A premium red velvet birthday cake finished with silky buttercream roses and a champagne-gold accent.', images: [images.velvet, images.designer, images.truffle], flavors: ['Red velvet', 'Vanilla bean', 'Chocolate'], sizes: ['6 in', '8 in', '10 in'], weights: ['1 kg', '1.5 kg', '2 kg'], tags: ['birthday', 'romantic', 'fresh cream'], reviewsData: [{ name: 'Mia', rating: 5, copy: 'The presentation was elegant and the taste was unforgettable.' }, { name: 'Ava', rating: 5, copy: 'Perfect for a milestone birthday and delivered beautifully.' }] },
    { id: 'p-02', slug: 'celestial-white-wedding', name: 'Celestial White Wedding Cake', category: 'Wedding Cakes', price: 164, rating: 5.0, reviews: 94, featured: true, bestseller: true, badge: 'Luxury', availability: 'Pre-order', delivery: '2 days', description: 'A towering white wedding cake with sugar florals, pearl detailing, and a refined, modern silhouette.', images: [images.wedding, images.designer, images.velvet], flavors: ['Vanilla bean', 'Almond cream', 'Pistachio'], sizes: ['8 in', '10 in', '12 in'], weights: ['2 kg', '3 kg', '4 kg'], tags: ['wedding', 'luxury', 'tiered'], reviewsData: [{ name: 'Sofia', rating: 5, copy: 'Absolutely breathtaking and worthy of the wedding photos.' }, { name: 'Nora', rating: 5, copy: 'The detailing was flawless and the cake was moist throughout.' }] },
    { id: 'p-03', slug: 'amber-anniversary-celebration', name: 'Amber Anniversary Celebration', category: 'Anniversary Cakes', price: 96, rating: 4.8, reviews: 76, featured: true, bestseller: false, badge: 'Elegant', availability: 'In stock', delivery: 'Next day', description: 'A warm caramel-toned anniversary cake with gold leaf edges and a silky vanilla bean filling.', images: [images.designer, images.velvet, images.wedding], flavors: ['Caramel', 'Vanilla bean', 'Hazelnut'], sizes: ['6 in', '8 in', '10 in'], weights: ['1 kg', '1.5 kg', '2 kg'], tags: ['anniversary', 'gold leaf', 'caramel'], reviewsData: [{ name: 'Liam', rating: 5, copy: 'Our anniversary dinner felt like a fine dining experience.' }, { name: 'Ella', rating: 4, copy: 'Beautiful and the caramel notes were rich without being heavy.' }] },
    { id: 'p-04', slug: 'mirror-glaze-designer', name: 'Mirror Glaze Designer Cake', category: 'Designer Cakes', price: 112, rating: 4.9, reviews: 105, featured: false, bestseller: true, badge: 'Designer', availability: 'In stock', delivery: 'Next day', description: 'A sleek mirror-glaze creation with artistic color bands and a glossy finish for modern celebrations.', images: [images.designer, images.truffle, images.velvet], flavors: ['Berry mousse', 'Dark chocolate', 'Pistachio'], sizes: ['6 in', '8 in', '10 in'], weights: ['1 kg', '1.5 kg', '2 kg'], tags: ['designer', 'mirror glaze', 'modern'], reviewsData: [{ name: 'Zara', rating: 5, copy: 'The glaze was stunning and it looked even better than the photos.' }, { name: 'Henry', rating: 5, copy: 'A true showpiece for our event.' }] },
    { id: 'p-05', slug: 'belgian-truffle-chocolate', name: 'Belgian Truffle Chocolate Cake', category: 'Chocolate Cakes', price: 84, rating: 4.9, reviews: 143, featured: true, bestseller: true, badge: 'Best Seller', availability: 'In stock', delivery: 'Same day', description: 'Deep cocoa sponge layered with Belgian truffle cream and a glossy ganache finish.', images: [images.truffle, images.velvet, images.pastry], flavors: ['Dark chocolate', 'Mocha', 'Nutella'], sizes: ['6 in', '8 in', '10 in'], weights: ['1 kg', '1.5 kg', '2 kg'], tags: ['chocolate', 'truffle', 'ganache'], reviewsData: [{ name: 'Ethan', rating: 5, copy: 'Rich, smooth, and deeply chocolate without being overly sweet.' }, { name: 'Grace', rating: 5, copy: 'This is the cake I would reorder again and again.' }] },
    { id: 'p-06', slug: 'summer-orchard-fruit', name: 'Summer Orchard Fruit Cake', category: 'Fruit Cakes', price: 88, rating: 4.7, reviews: 87, featured: false, bestseller: true, badge: 'Fresh', availability: 'In stock', delivery: 'Next day', description: 'A bright, fruit-forward cake layered with seasonal berries, citrus cream, and soft vanilla sponge.', images: [images.fruit, images.designer, images.wedding], flavors: ['Berry compote', 'Vanilla', 'Citrus'], sizes: ['6 in', '8 in', '10 in'], weights: ['1 kg', '1.5 kg', '2 kg'], tags: ['fruit', 'fresh', 'seasonal'], reviewsData: [{ name: 'Lily', rating: 5, copy: 'Fresh and light, perfect after dinner.' }, { name: 'James', rating: 4, copy: 'The fruit flavor felt premium and natural.' }] },
    { id: 'p-07', slug: 'little-explorer-kids', name: 'Little Explorer Kids Cake', category: 'Kids Cakes', price: 72, rating: 4.8, reviews: 69, featured: false, bestseller: false, badge: 'Fun', availability: 'In stock', delivery: 'Same day', description: 'A playful kids cake finished with colorful chocolate details and a cheerful party-ready design.', images: [images.velvet, images.designer, images.pastry], flavors: ['Vanilla', 'Chocolate', 'Strawberry'], sizes: ['6 in', '8 in', '10 in'], weights: ['1 kg', '1.5 kg', '2 kg'], tags: ['kids', 'birthday', 'colorful'], reviewsData: [{ name: 'Olivia', rating: 5, copy: 'Our child loved the design and the cake vanished quickly.' }, { name: 'Noah', rating: 5, copy: 'Bright, fun, and delicious.' }] },
    { id: 'p-08', slug: 'maison-vanilla-cupcakes', name: 'Maison Vanilla Cupcakes', category: 'Cupcakes', price: 38, rating: 4.9, reviews: 112, featured: false, bestseller: true, badge: 'Box Set', availability: 'In stock', delivery: 'Same day', description: 'A refined box of vanilla cupcakes with silky frosting and delicate seasonal toppings.', images: [images.pastry, images.fruit, images.velvet], flavors: ['Vanilla', 'Chocolate', 'Lemon'], sizes: ['6 pcs', '12 pcs', '24 pcs'], weights: ['Half dozen', '1 dozen', '2 dozen'], tags: ['cupcakes', 'dessert box', 'gifting'], reviewsData: [{ name: 'Chloe', rating: 5, copy: 'Beautiful packaging and every cupcake tasted fresh.' }, { name: 'Owen', rating: 5, copy: 'Ideal for office celebrations.' }] },
    { id: 'p-09', slug: 'almond-butter-pastries', name: 'Almond Butter Pastries', category: 'Pastries', price: 32, rating: 4.6, reviews: 61, featured: false, bestseller: false, badge: 'Classic', availability: 'In stock', delivery: 'Same day', description: 'A box of buttery pastries with almond cream, crisp layers, and a luxurious bakery finish.', images: [images.pastry, images.fruit, images.truffle], flavors: ['Almond', 'Vanilla', 'Pistachio'], sizes: ['4 pcs', '6 pcs', '12 pcs'], weights: ['Small box', 'Medium box', 'Large box'], tags: ['pastries', 'almond', 'box'], reviewsData: [{ name: 'Aria', rating: 5, copy: 'The pastry layers were delicate and very fresh.' }, { name: 'Jack', rating: 4, copy: 'Lovely for a tea table or brunch gift.' }] },
    { id: 'p-10', slug: 'silken-eggless-vanilla', name: 'Silken Eggless Vanilla Cake', category: 'Eggless Cakes', price: 74, rating: 4.8, reviews: 91, featured: false, bestseller: true, badge: 'Eggless', availability: 'In stock', delivery: 'Same day', description: 'A soft, elegant eggless vanilla cake layered with whipped cream and a delicate vanilla bean finish.', images: [images.velvet, images.wedding, images.pastry], flavors: ['Vanilla bean', 'Strawberry', 'Chocolate'], sizes: ['6 in', '8 in', '10 in'], weights: ['1 kg', '1.5 kg', '2 kg'], tags: ['eggless', 'vanilla', 'light cream'], reviewsData: [{ name: 'Ivy', rating: 5, copy: 'It tasted as rich as any classic cake and suited everyone at the table.' }, { name: 'Leo', rating: 5, copy: 'Elegant and inclusive, exactly what we needed.' }] },
    { id: 'p-11', slug: 'pistachio-raspberry-mirror', name: 'Pistachio Raspberry Mirror', category: 'Designer Cakes', price: 118, rating: 4.9, reviews: 74, featured: true, bestseller: false, badge: 'Artisan', availability: 'Pre-order', delivery: '2 days', description: 'A sophisticated pistachio and raspberry designer cake with a polished mirror finish and fresh berry garnish.', images: [images.designer, images.fruit, images.wedding], flavors: ['Pistachio', 'Raspberry', 'Vanilla'], sizes: ['6 in', '8 in', '10 in'], weights: ['1 kg', '1.5 kg', '2 kg'], tags: ['designer', 'pistachio', 'mirror'], reviewsData: [{ name: 'Sophia', rating: 5, copy: 'A perfect balance of tart and creamy flavors.' }, { name: 'Mason', rating: 5, copy: 'The finish was glossy and elegant.' }] },
    { id: 'p-12', slug: 'gold-dust-anniversary', name: 'Gold Dust Anniversary Cake', category: 'Anniversary Cakes', price: 102, rating: 4.8, reviews: 66, featured: false, bestseller: false, badge: 'Celebration', availability: 'In stock', delivery: 'Next day', description: 'A romantic anniversary centerpiece with gold leaf dusting, vanilla sponge, and silky mascarpone cream.', images: [images.wedding, images.velvet, images.designer], flavors: ['Vanilla', 'Chocolate', 'Caramel'], sizes: ['6 in', '8 in', '10 in'], weights: ['1 kg', '1.5 kg', '2 kg'], tags: ['anniversary', 'gold leaf', 'romantic'], reviewsData: [{ name: 'Amelia', rating: 5, copy: 'Beautiful and timeless for our anniversary dinner.' }, { name: 'Benjamin', rating: 4, copy: 'Elegant design and excellent texture.' }] }
  ];

  const categories = ['All', 'Birthday Cakes', 'Wedding Cakes', 'Anniversary Cakes', 'Designer Cakes', 'Chocolate Cakes', 'Fruit Cakes', 'Kids Cakes', 'Cupcakes', 'Pastries', 'Eggless Cakes'];

  const testimonials = [
    { name: 'Camila', role: 'Wedding client', quote: 'Sweet Delights made our wedding cake feel like couture.' },
    { name: 'Dylan', role: 'Birthday client', quote: 'Ordering was effortless and the cake arrived perfect.' },
    { name: 'Priya', role: 'Corporate gifting', quote: 'The packaging, flavor, and service were all premium.' }
  ];

  const team = [
    { name: 'Elena Hart', role: 'Executive Pastry Chef', image: images.wedding },
    { name: 'Marco Lee', role: 'Cake Artist', image: images.designer },
    { name: 'Sofia Chen', role: 'Guest Experience Lead', image: images.pastry }
  ];

  function formatPrice(value) {
    return currency.format(Number(value || 0));
  }

  function getProduct(idOrSlug) {
    return products.find((item) => item.id === idOrSlug || item.slug === idOrSlug) || null;
  }

  function getRelatedProducts(product, limit = 4) {
    if (!product) return products.slice(0, limit);
    return products
      .filter((item) => item.slug !== product.slug)
      .sort((a, b) => (a.category === product.category ? -1 : 0) || (b.featured - a.featured))
      .slice(0, limit);
  }

  function searchProducts(query = '', category = 'All') {
    const q = query.trim().toLowerCase();
    return products.filter((product) => {
      const matchesQuery = !q || [product.name, product.category, product.description, ...product.tags].join(' ').toLowerCase().includes(q);
      const matchesCategory = category === 'All' || product.category === category;
      return matchesQuery && matchesCategory;
    });
  }

  function sortProducts(list, sort = 'featured') {
    const clone = [...list];
    if (sort === 'price-asc') return clone.sort((a, b) => a.price - b.price);
    if (sort === 'price-desc') return clone.sort((a, b) => b.price - a.price);
    if (sort === 'rating-desc') return clone.sort((a, b) => b.rating - a.rating);
    return clone.sort((a, b) => Number(b.featured) - Number(a.featured) || Number(b.bestseller) - Number(a.bestseller) || b.reviews - a.reviews);
  }

  window.SweetDelightsData = { products, categories, testimonials, team, images, formatPrice, getProduct, getRelatedProducts, searchProducts, sortProducts };
})();
