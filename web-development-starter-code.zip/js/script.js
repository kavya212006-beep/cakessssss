(function () {
  const SD = window.SweetDelightsData;
  const Store = window.SweetDelightsStore;
  const Auth = window.SweetDelightsAuth;
  const body = document.body;

  const state = {
    page: body.dataset.page || 'home',
    mode: body.dataset.mode || '',
    catalog: { page: 1, perPage: 8, query: '', category: 'All', sort: 'featured' }
  };

  function qs(selector, root = document) { return root.querySelector(selector); }
  function qsa(selector, root = document) { return Array.from(root.querySelectorAll(selector)); }

  function escapeHtml(value = '') {
    return String(value)
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;')
      .replaceAll('"', '&quot;')
      .replaceAll("'", '&#39;');
  }

  function toast(title, message = '', type = 'info') {
    const root = qs('#toastRoot');
    if (!root) return;
    const el = document.createElement('div');
    el.className = `toast notification ${type}`;
    el.innerHTML = `<strong>${escapeHtml(title)}</strong>${message ? `<div class="muted-text">${escapeHtml(message)}</div>` : ''}`;
    root.appendChild(el);
    setTimeout(() => { el.style.opacity = '0'; el.style.transform = 'translateY(10px)'; }, 2600);
    setTimeout(() => el.remove(), 3200);
  }

  function setLoader(show) {
    const loader = qs('#pageLoader');
    if (!loader) return;
    loader.classList.toggle('hidden', !show);
  }

  function setActiveNav() {
    qsa('.nav-links a').forEach((link) => {
      const href = link.getAttribute('href') || '';
      const current = location.pathname.split('/').pop() || 'index.html';
      if (href === current || (current === '' && href === 'index.html')) link.classList.add('active');
    });
  }

  function renderHeader() {
    const header = qs('#site-header');
    if (!header) return;
    header.innerHTML = `
      <header class="site-header">
        <div class="nav-shell">
          <a class="brand" href="index.html"><span class="brand-mark"></span>Sweet Delights</a>
          <nav class="nav-links" id="primaryNav">
            <a href="index.html">Home</a>
            <a href="products.html">Cakes</a>
            <a href="customize.html">Customize</a>
            <a href="tracking.html">Track order</a>
            <a href="about.html">About</a>
            <a href="contact.html">Contact</a>
            <a href="dashboard.html">Account</a>
          </nav>
          <div class="nav-actions">
            <button class="theme-btn" id="themeToggle" aria-label="Toggle theme">Theme</button>
            <a class="icon-btn" href="cart.html" aria-label="Cart">Cart <span class="count-chip" data-cart-count>0</span></a>
            <a class="icon-btn" href="dashboard.html" aria-label="Wishlist">Wish <span class="count-chip" data-wishlist-count>0</span></a>
            <button class="menu-btn" id="menuToggle" aria-label="Open menu">Menu</button>
          </div>
        </div>
      </header>`;
  }

  function renderFooter() {
    const footer = qs('#site-footer');
    if (!footer) return;
    footer.innerHTML = `
      <footer class="site-footer section-pad">
        <div class="container footer-grid">
          <div>
            <div class="footer-brand">Sweet Delights</div>
            <p class="footer-muted">Luxury cakes, custom celebration designs, and elegant delivery for every memorable moment.</p>
          </div>
          <div>
            <h3>Shop</h3>
            <div class="footer-links"><a href="products.html">Catalog</a><a href="customize.html">Customize</a><a href="cart.html">Cart</a><a href="checkout.html">Checkout</a></div>
          </div>
          <div>
            <h3>Company</h3>
            <div class="footer-links"><a href="about.html">About</a><a href="contact.html">Contact</a><a href="tracking.html">Track</a><a href="dashboard.html">Account</a></div>
          </div>
          <div>
            <h3>Newsletter</h3>
            <form class="stack-form" id="footerNewsletter"><input type="email" placeholder="Email address" required><button class="btn btn-primary" type="submit">Join</button></form>
          </div>
        </div>
      </footer>`;
  }

  function renderChatWidget() {
    const widget = qs('#chatWidget');
    if (!widget) return;
    widget.innerHTML = `
      <button class="btn btn-primary chat-launcher" id="chatOpen">Live chat</button>
      <div class="chat-panel hidden" id="chatPanel">
        <header><strong>Sweet Delights Concierge</strong></header>
        <div class="messages" id="chatMessages"><div class="bubble bot">Hello. How can we help you choose the perfect cake?</div></div>
        <footer>
          <form class="stack-form" id="chatForm">
            <input type="text" id="chatInput" placeholder="Type your message">
            <button class="btn btn-secondary" type="submit">Send</button>
          </form>
        </footer>
      </div>`;
    qs('#chatOpen').addEventListener('click', () => qs('#chatPanel').classList.toggle('hidden'));
    qs('#chatForm').addEventListener('submit', (event) => {
      event.preventDefault();
      const input = qs('#chatInput');
      const msg = input.value.trim();
      if (!msg) return;
      const messages = qs('#chatMessages');
      messages.insertAdjacentHTML('beforeend', `<div class="bubble me">${escapeHtml(msg)}</div><div class="bubble bot">Thanks. We will help with that shortly.</div>`);
      input.value = '';
      messages.scrollTop = messages.scrollHeight;
    });
  }

  function updateCounts() {
    const cartCount = qs('[data-cart-count]');
    const wishCount = qs('[data-wishlist-count]');
    if (cartCount) cartCount.textContent = Store.getCartCount();
    if (wishCount) wishCount.textContent = Store.getWishlist().length;
  }

  function initTheme() {
    const saved = localStorage.getItem('sweet_delights_theme') || 'dark';
    body.classList.toggle('theme-light', saved === 'light');
    const btn = qs('#themeToggle');
    if (btn) {
      btn.textContent = saved === 'light' ? 'Dark' : 'Light';
      btn.addEventListener('click', () => {
        const light = !body.classList.contains('theme-light');
        body.classList.toggle('theme-light', light);
        localStorage.setItem('sweet_delights_theme', light ? 'light' : 'dark');
        btn.textContent = light ? 'Dark' : 'Light';
      });
    }
  }

  function initMenu() {
    const nav = qs('#primaryNav');
    const btn = qs('#menuToggle');
    if (!nav || !btn) return;
    btn.addEventListener('click', () => nav.classList.toggle('open'));
  }

  function bindPageTransitions() {
    document.addEventListener('click', (event) => {
      const link = event.target.closest('a[href]');
      if (!link) return;
      const href = link.getAttribute('href') || '';
      if (href.startsWith('#') || href.startsWith('mailto:') || href.startsWith('tel:') || link.target === '_blank') return;
      setLoader(true);
    });
  }

  function pageTemplateProductCard(product) {
    const wish = Store.isWishlisted(product.slug) ? 'Wishlisted' : 'Wishlist';
    return `
      <article class="product-card reveal">
        <a class="product-media" href="product-details.html?slug=${encodeURIComponent(product.slug)}"><img src="${product.images[0]}" alt="${escapeHtml(product.name)}" loading="lazy"></a>
        <div class="product-body">
          <div class="meta-row"><span class="badge-soft">${escapeHtml(product.category)}</span><span class="rating">${product.rating.toFixed(1)}/5</span></div>
          <h3 class="product-title">${escapeHtml(product.name)}</h3>
          <p class="card-copy">${escapeHtml(product.description)}</p>
          <div class="sub-row"><strong>${SD.formatPrice(product.price)}</strong><span class="subtle-label">${escapeHtml(product.delivery)}</span></div>
          <div class="action-row">
            <button class="btn btn-primary js-add-to-cart" data-slug="${product.slug}">Add to cart</button>
            <button class="btn btn-secondary js-quick-view" data-slug="${product.slug}">Quick view</button>
            <button class="btn btn-ghost js-toggle-wishlist" data-slug="${product.slug}">${wish}</button>
          </div>
        </div>
      </article>`;
  }

  function renderHome() {
    const featured = SD.products.filter((item) => item.featured).slice(0, 4);
    const best = SD.products.filter((item) => item.bestseller).slice(0, 4);
    const featuredRoot = qs('#homeFeatured');
    const bestRoot = qs('#homeBestSellers');
    const catRoot = qs('#homeCategories');
    const testRoot = qs('#homeTestimonials');
    const instaRoot = qs('#homeInstagram');
    if (featuredRoot) featuredRoot.innerHTML = featured.map(pageTemplateProductCard).join('');
    if (bestRoot) bestRoot.innerHTML = best.map(pageTemplateProductCard).join('');
    if (catRoot) {
      catRoot.innerHTML = SD.categories.filter((c) => c !== 'All').map((category) => `
        <a class="category-card" href="products.html?category=${encodeURIComponent(category)}">
          <div class="category-body">
            <span class="badge-soft">Explore</span>
            <h3 class="card-title">${escapeHtml(category)}</h3>
          </div>
        </a>`).join('');
    }
    if (testRoot) {
      testRoot.innerHTML = SD.testimonials.map((item) => `
        <article class="testimonial-card"><div class="testimonial-body"><p class="body-copy">${escapeHtml(item.quote)}</p><strong>${escapeHtml(item.name)}</strong><div class="review-meta">${escapeHtml(item.role)}</div></div></article>`).join('');
    }
    if (instaRoot) {
      const imgs = SD.products.flatMap((item) => item.images).slice(0, 6);
      instaRoot.innerHTML = imgs.map((src) => `<img src="${src}" alt="Sweet Delights gallery" loading="lazy">`).join('');
    }
    const form = qs('#newsletterForm');
    if (form) form.addEventListener('submit', handleNewsletter);
  }

  function handleNewsletter(event) {
    event.preventDefault();
    toast('Subscribed', 'You are on the Sweet Delights newsletter list.');
    event.target.reset();
  }

  function bindActionClicks() {
    document.addEventListener('click', (event) => {
      const addBtn = event.target.closest('.js-add-to-cart');
      const wishBtn = event.target.closest('.js-toggle-wishlist');
      const quickBtn = event.target.closest('.js-quick-view');
      const qtyBtn = event.target.closest('[data-qty-action]');
      const removeBtn = event.target.closest('[data-remove-key]');
      if (addBtn) {
        const product = SD.getProduct(addBtn.dataset.slug);
        if (!product) return;
        Store.addToCart(product, 1, {});
        updateCounts();
        toast('Added to cart', product.name);
      }
      if (wishBtn) {
        const product = SD.getProduct(wishBtn.dataset.slug);
        if (!product) return;
        Store.toggleWishlist(product.slug);
        updateCounts();
        toast('Wishlist updated', product.name);
        if (state.page === 'catalog') renderCatalog();
      }
      if (quickBtn) {
        openQuickView(SD.getProduct(quickBtn.dataset.slug));
      }
      if (qtyBtn) {
        const key = qtyBtn.dataset.key;
        const action = qtyBtn.dataset.qtyAction;
        const cart = Store.getCart();
        const item = cart.find((entry) => entry.key === key);
        if (!item) return;
        const next = action === 'plus' ? item.quantity + 1 : Math.max(1, item.quantity - 1);
        Store.updateCartItem(key, next);
        renderCart();
        updateCounts();
      }
      if (removeBtn) {
        Store.removeCartItem(removeBtn.dataset.removeKey);
        renderCart();
        updateCounts();
      }
    });
  }

  function openQuickView(product) {
    const modal = qs('#quickViewModal');
    if (!modal || !product) return;
    modal.innerHTML = `
      <div class="modal-card">
        <div class="split-grid align-start">
          <div class="hero-media-card"><img src="${product.images[0]}" alt="${escapeHtml(product.name)}"></div>
          <div class="panel-soft">
            <p class="eyebrow">Quick view</p>
            <h3 class="quick-view-title">${escapeHtml(product.name)}</h3>
            <p class="body-copy">${escapeHtml(product.description)}</p>
            <div class="info-row"><strong>${SD.formatPrice(product.price)}</strong><span class="rating">${product.rating.toFixed(1)}/5</span></div>
            <div class="btn-row">
              <button class="btn btn-primary js-add-to-cart" data-slug="${product.slug}">Add to cart</button>
              <a class="btn btn-secondary" href="product-details.html?slug=${encodeURIComponent(product.slug)}">Open details</a>
            </div>
          </div>
        </div>
      </div>`;
    modal.classList.remove('hidden');
    modal.addEventListener('click', (event) => { if (event.target === modal) modal.classList.add('hidden'); }, { once: true });
  }

  function renderCatalog() {
    const grid = qs('#catalogGrid');
    if (!grid) return;
    const search = qs('#catalogSearch');
    const category = qs('#catalogCategory');
    const sort = qs('#catalogSort');
    const params = new URLSearchParams(location.search);
    if (category && !category.dataset.ready) {
      category.innerHTML = SD.categories.map((item) => `<option value="${escapeHtml(item)}">${escapeHtml(item)}</option>`).join('');
      category.dataset.ready = '1';
    }
    state.catalog.query = params.get('q') ?? search?.value ?? '';
    state.catalog.category = params.get('category') ?? category?.value ?? 'All';
    state.catalog.sort = params.get('sort') ?? sort?.value ?? 'featured';
    if (search) search.value = state.catalog.query;
    if (category) category.value = state.catalog.category;
    if (sort) sort.value = state.catalog.sort;
    const filtered = SD.sortProducts(SD.searchProducts(state.catalog.query, state.catalog.category), state.catalog.sort);
    const pageCount = Math.max(1, Math.ceil(filtered.length / state.catalog.perPage));
    state.catalog.page = Math.min(state.catalog.page, pageCount);
    const slice = filtered.slice((state.catalog.page - 1) * state.catalog.perPage, state.catalog.page * state.catalog.perPage);
    grid.innerHTML = slice.map(pageTemplateProductCard).join('') || '<div class="page-card empty-state">No cakes match your search.</div>';
    const pagination = qs('#catalogPagination');
    if (pagination) {
      pagination.innerHTML = Array.from({ length: pageCount }, (_, index) => `<button class="${index + 1 === state.catalog.page ? 'active' : ''}" data-page="${index + 1}">${index + 1}</button>`).join('');
      qsa('button[data-page]', pagination).forEach((btn) => btn.addEventListener('click', () => { state.catalog.page = Number(btn.dataset.page); renderCatalog(); }));
    }
    [search, category, sort].forEach((control) => {
      if (control && !control.dataset.bound) {
        control.addEventListener('input', () => { state.catalog.page = 1; renderCatalog(); });
        control.dataset.bound = '1';
      }
    });
    const modal = qs('#quickViewModal');
    if (modal) modal.innerHTML = '';
  }

  function renderDetail() {
    const root = qs('#detailRoot');
    if (!root) return;
    const params = new URLSearchParams(location.search);
    const product = SD.getProduct(params.get('slug')) || SD.products[0];
    Store.addRecent(product);
    updateCounts();
    const thumbs = product.images.map((src, index) => `<button class="thumb-btn" data-image="${src}" aria-label="Image ${index + 1}"><img src="${src}" alt="${escapeHtml(product.name)}"></button>`).join('');
    root.innerHTML = `
      <div class="breadcrumb"><a href="index.html">Home</a> / <a href="products.html">Cakes</a> / ${escapeHtml(product.name)}</div>
      <section class="detail-grid">
        <div class="panel-stack">
          <div class="zoom-stage"><div class="zoom-frame" id="zoomFrame" style="background-image:url('${product.images[0]}')"></div></div>
          <div class="thumb-row">${thumbs}</div>
        </div>
        <div class="glass panel-soft">
          <p class="eyebrow">${escapeHtml(product.category)}</p>
          <h1 class="page-title">${escapeHtml(product.name)}</h1>
          <p class="body-copy">${escapeHtml(product.description)}</p>
          <div class="info-row"><span class="price-box">${SD.formatPrice(product.price)}</span><span class="rating">${product.rating.toFixed(1)}/5 from ${product.reviews} reviews</span></div>
          <div class="summary-list">
            <div><strong>Availability</strong><span>${escapeHtml(product.availability)}</span></div>
            <div><strong>Delivery</strong><span>${escapeHtml(product.delivery)}</span></div>
            <div><strong>Flavors</strong><span>${product.flavors.join(', ')}</span></div>
          </div>
          <div class="btn-row">
            <button class="btn btn-primary js-add-to-cart" data-slug="${product.slug}">Add to cart</button>
            <a class="btn btn-secondary" href="checkout.html">Buy now</a>
            <button class="btn btn-ghost js-toggle-wishlist" data-slug="${product.slug}">Wishlist</button>
          </div>
        </div>
      </section>
      <section class="section-gap split-grid align-start">
        <div class="glass panel-soft">
          <p class="eyebrow">Reviews</p>
          <div class="review-stack">${product.reviewsData.map((review) => `<article class="review-card"><div class="review-body"><strong>${escapeHtml(review.name)}</strong><div class="review-meta">${review.rating.toFixed(1)}/5</div><p class="review-copy">${escapeHtml(review.copy)}</p></div></article>`).join('')}</div>
        </div>
        <div class="glass panel-soft">
          <p class="eyebrow">Availability</p>
          <p class="body-copy">Order before 3 PM for same-day delivery on selected cakes.</p>
          <div class="summary-list"><div><strong>Weight guide</strong><span>${product.weights.join(', ')}</span></div><div><strong>Size guide</strong><span>${product.sizes.join(', ')}</span></div></div>
        </div>
      </section>`;
    const zoom = qs('#zoomFrame');
    if (zoom) {
      zoom.addEventListener('mousemove', (event) => {
        const rect = zoom.getBoundingClientRect();
        const x = ((event.clientX - rect.left) / rect.width) * 100;
        const y = ((event.clientY - rect.top) / rect.height) * 100;
        zoom.style.backgroundPosition = `${x}% ${y}%`;
        zoom.style.backgroundSize = '165%';
      });
      zoom.addEventListener('mouseleave', () => { zoom.style.backgroundPosition = 'center'; zoom.style.backgroundSize = '140%'; });
    }
    qsa('.thumb-btn').forEach((btn) => btn.addEventListener('click', () => { if (zoom) zoom.style.backgroundImage = `url('${btn.dataset.image}')`; }));
    const recRoot = qs('#recommendedProducts');
    if (recRoot) recRoot.innerHTML = SD.getRelatedProducts(product, 4).map(pageTemplateProductCard).join('');
  }

  function renderCustomization() {
    const productSelect = qs('#customProduct');
    const flavorSelect = qs('#customFlavor');
    const sizeSelect = qs('#customSize');
    const weightSelect = qs('#customWeight');
    const summary = qs('#customQuote');
    if (!productSelect || !summary) return;
    const flavors = ['Vanilla bean', 'Chocolate truffle', 'Red velvet', 'Pistachio raspberry', 'Fruit medley'];
    const sizes = ['6 in', '8 in', '10 in'];
    const weights = ['1 kg', '1.5 kg', '2 kg'];
    productSelect.innerHTML = SD.products.slice(0, 8).map((item) => `<option value="${item.slug}">${item.name}</option>`).join('');
    flavorSelect.innerHTML = flavors.map((item) => `<option>${item}</option>`).join('');
    sizeSelect.innerHTML = sizes.map((item) => `<option>${item}</option>`).join('');
    weightSelect.innerHTML = weights.map((item) => `<option>${item}</option>`).join('');
    qs('#customDate').min = new Date().toISOString().slice(0, 10);
    qs('#customTime').value = '12:00';
    const breakdown = () => {
      const product = SD.getProduct(productSelect.value);
      const flavor = flavorSelect.value;
      const size = sizeSelect.value;
      const weight = weightSelect.value;
      const message = qs('#customMessage').value.trim();
      const date = qs('#customDate').value;
      const time = qs('#customTime').value;
      const image = qs('#customImage').files[0];
      let extra = 0;
      extra += flavor.includes('Chocolate') ? 12 : flavor.includes('Pistachio') ? 16 : flavor.includes('Fruit') ? 14 : 8;
      extra += size === '8 in' ? 18 : size === '10 in' ? 36 : 0;
      extra += weight === '1.5 kg' ? 14 : weight === '2 kg' ? 26 : 0;
      extra += message ? 8 : 0;
      extra += image ? 15 : 0;
      if (date) {
        const diff = Math.ceil((new Date(date).getTime() - Date.now()) / 86400000);
        if (diff < 3) extra += 18;
      }
      if (time && Number(time.slice(0, 2)) >= 17) extra += 5;
      const final = product.price + extra;
      summary.innerHTML = `
        <p class="eyebrow">Price quote</p>
        <h2>${escapeHtml(product.name)}</h2>
        <div class="summary-list">
          <div><strong>Base price</strong><span>${SD.formatPrice(product.price)}</span></div>
          <div><strong>Custom options</strong><span>${SD.formatPrice(extra)}</span></div>
          <div><strong>Final price</strong><span class="price-box">${SD.formatPrice(final)}</span></div>
        </div>
        <div class="body-copy">Flavor: ${escapeHtml(flavor)}<br>Size: ${escapeHtml(size)}<br>Weight: ${escapeHtml(weight)}<br>Delivery: ${escapeHtml(date || 'Select a date')} ${escapeHtml(time || '')}</div>
        <button class="btn btn-primary" id="addCustomToCart">Add to cart</button>`;
      const addCustom = qs('#addCustomToCart');
      if (addCustom) addCustom.onclick = () => {
        Store.addToCart(product, 1, { custom: true, flavor, size, weight, message, date, time, final });
        updateCounts();
        toast('Custom cake added', product.name);
      };
      return { final, product, flavor, size, weight, message, date, time };
    };
    [productSelect, flavorSelect, sizeSelect, weightSelect, qs('#customMessage'), qs('#customDate'), qs('#customTime'), qs('#customImage')].forEach((control) => control && control.addEventListener('input', breakdown));
    breakdown();
  }

  function renderCart() {
    const list = qs('#cartList');
    const summary = qs('#cartSummary');
    if (!list || !summary) return;
    const cart = Store.getCart();
    const couponCode = Store.getCoupon();
    if (!cart.length) {
      list.innerHTML = '<div class="empty-state">Your cart is empty. Browse cakes to start your order.</div>';
    } else {
      list.innerHTML = cart.map((item) => `
        <article class="product-card"><div class="product-body"><div class="meta-row"><span class="badge-soft">${escapeHtml(item.category)}</span><span>${SD.formatPrice(item.price)}</span></div><div class="info-row"><h3 class="product-title">${escapeHtml(item.name)}</h3><div class="quantity-box"><button data-qty-action="minus" data-key="${item.key}">-</button><span>${item.quantity}</span><button data-qty-action="plus" data-key="${item.key}">+</button></div></div><div class="review-meta">${item.options?.custom ? 'Custom cake order' : 'Standard cake'}${item.options?.message ? ` - ${escapeHtml(item.options.message)}` : ''}</div><div class="btn-row"><button class="btn btn-secondary" data-remove-key="${item.key}">Remove</button></div></div></article>`).join('');
    }
    const totals = Store.getCartTotals(cart, couponCode);
    summary.innerHTML = `
      <p class="eyebrow">Order summary</p>
      <div class="summary-list">
        <div><strong>Subtotal</strong><span>${SD.formatPrice(totals.subtotal)}</span></div>
        <div><strong>Coupon</strong><span>${totals.coupon ? `${totals.coupon.label} (-${SD.formatPrice(totals.discount)})` : 'None'}</span></div>
        <div><strong>Delivery</strong><span>${totals.delivery === 0 ? 'Free' : SD.formatPrice(totals.delivery)}</span></div>
        <div><strong>Tax</strong><span>${SD.formatPrice(totals.tax)}</span></div>
        <div><strong>Total</strong><span class="price-box">${SD.formatPrice(totals.total)}</span></div>
      </div>
      <form id="couponForm" class="stack-form"><input id="couponInput" value="${escapeHtml(couponCode)}" placeholder="Coupon code"><button class="btn btn-secondary" type="submit">Apply coupon</button></form>
      <div class="btn-row"><a class="btn btn-primary" href="checkout.html">Checkout</a><button class="btn btn-ghost" id="clearCartBtn">Clear cart</button></div>`;
    const couponForm = qs('#couponForm');
    const clearBtn = qs('#clearCartBtn');
    if (couponForm) couponForm.addEventListener('submit', (event) => {
      event.preventDefault();
      const code = qs('#couponInput').value;
      Store.setCoupon(code);
      renderCart();
    });
    if (clearBtn) clearBtn.addEventListener('click', () => { Store.clearCart(); renderCart(); updateCounts(); toast('Cart cleared'); });
  }

  function renderCheckout() {
    const review = qs('#orderReview');
    const form = qs('#checkoutForm');
    if (!review || !form) return;
    const cart = Store.getCart();
    if (!cart.length) {
      review.innerHTML = '<div class="empty-state">Your cart is empty. Add cakes before checkout.</div>';
      return;
    }
    const totals = Store.getCartTotals(cart, Store.getCoupon());
    review.innerHTML = `
      <p class="eyebrow">Order review</p>
      <div class="stack-space">${cart.map((item) => `<div class="summary-row"><span>${escapeHtml(item.name)} x${item.quantity}</span><strong>${SD.formatPrice(item.price * item.quantity)}</strong></div>`).join('')}</div>
      <div class="summary-list">
        <div><strong>Subtotal</strong><span>${SD.formatPrice(totals.subtotal)}</span></div>
        <div><strong>Delivery</strong><span>${totals.delivery === 0 ? 'Free' : SD.formatPrice(totals.delivery)}</span></div>
        <div><strong>Tax</strong><span>${SD.formatPrice(totals.tax)}</span></div>
        <div><strong>Total</strong><span class="price-box">${SD.formatPrice(totals.total)}</span></div>
      </div>`;
    const currentUser = Auth.getCurrentUser();
    if (currentUser) {
      qs('#billingName').value = currentUser.name;
      qs('#billingEmail').value = currentUser.email;
    }
    form.addEventListener('submit', (event) => {
      event.preventDefault();
      const order = Store.createOrderFromCart({
        customer: { name: qs('#billingName').value, email: qs('#billingEmail').value, phone: qs('#billingPhone').value },
        shippingAddress: qs('#billingAddress').value,
        paymentMethod: form.querySelector('input[name="paymentMethod"]:checked').value,
        couponCode: Store.getCoupon(),
        notes: 'Checkout order'
      });
      if (!order) return toast('Cart empty', 'Add items before placing an order.');
      toast('Order placed', `Tracking code ${order.trackingCode}`);
      location.href = `tracking.html?order=${encodeURIComponent(order.id)}`;
    });
  }

  function renderDashboard() {
    const root = qs('#dashboardRoot');
    if (!root) return;
    const user = Auth.getCurrentUser();
    const orders = Store.getOrders();
    const wishlist = Store.getWishlist().map((slug) => SD.getProduct(slug)).filter(Boolean);
    const recent = Store.getRecent().map((slug) => SD.getProduct(slug)).filter(Boolean);
    root.innerHTML = `
      <div class="dashboard-grid">
        <section class="glass panel-soft">
          <p class="eyebrow">Account</p>
          <h2>${user ? `Welcome, ${escapeHtml(user.name)}` : 'Sign in or create an account'}</h2>
          ${user ? `<div class="profile-stack"><div><strong>Email</strong><div>${escapeHtml(user.email)}</div></div><div><strong>Addresses</strong><div>${(user.addresses || []).join('<br>') || 'No saved address yet.'}</div></div><button class="btn btn-secondary" id="logoutBtn">Logout</button></div>` : `
            <div class="auth-tabs">
              <form class="stack-form auth-card" id="dashboardLogin"><h3>Login</h3><input type="email" placeholder="Email" required><input type="password" placeholder="Password" required><button class="btn btn-primary" type="submit">Login</button></form>
              <form class="stack-form auth-card" id="dashboardSignup"><h3>Signup</h3><input type="text" placeholder="Name" required><input type="email" placeholder="Email" required><input type="password" placeholder="Password" required><button class="btn btn-secondary" type="submit">Signup</button></form>
              <form class="stack-form auth-card" id="dashboardForgot"><h3>Forgot password</h3><input type="email" placeholder="Email" required><button class="btn btn-ghost" type="submit">Send reset</button></form>
            </div>`}
        </section>
        <section class="glass panel-soft">
          <p class="eyebrow">Profile</p>
          <form id="profileForm" class="stack-form">
            <input id="profileName" value="${escapeHtml(user?.name || '')}" placeholder="Full name">
            <input id="profileEmail" value="${escapeHtml(user?.email || '')}" placeholder="Email address">
            <button class="btn btn-primary" type="submit">Save profile</button>
          </form>
        </section>
      </div>
      <section class="section-gap split-grid align-start">
        <div class="glass panel-soft">
          <p class="eyebrow">Order history</p>
          ${orders.length ? orders.map((order) => `<article class="order-card"><div class="order-body"><div class="summary-row"><strong>${order.id}</strong><span class="status-pill active">${escapeHtml(order.status)}</span></div><div class="review-meta">${new Date(order.createdAt).toLocaleString()}</div><div class="summary-row"><span>${order.items.length} item(s)</span><strong>${SD.formatPrice(order.totals.total)}</strong></div></div></article>`).join('') : '<div class="empty-state">No orders yet.</div>'}
        </div>
        <div class="glass panel-soft">
          <p class="eyebrow">Wishlist and recently viewed</p>
          <div class="stack-space">${wishlist.length ? wishlist.map((item) => `<div class="summary-row"><span>${escapeHtml(item.name)}</span><a href="product-details.html?slug=${item.slug}">View</a></div>`).join('') : '<div class="empty-state">Your wishlist is empty.</div>'}</div>
          <div class="loader-line"></div>
          <div class="stack-space">${recent.length ? recent.map((item) => `<div class="summary-row"><span>${escapeHtml(item.name)}</span><a href="product-details.html?slug=${item.slug}">View again</a></div>`).join('') : '<div class="empty-state">Recently viewed items will appear here.</div>'}</div>
        </div>
      </section>`;
    const logoutBtn = qs('#logoutBtn');
    if (logoutBtn) logoutBtn.addEventListener('click', () => { Auth.logoutUser(); toast('Logged out'); renderDashboard(); });
    const loginForm = qs('#dashboardLogin');
    const signupForm = qs('#dashboardSignup');
    const forgotForm = qs('#dashboardForgot');
    if (loginForm) loginForm.addEventListener('submit', async (event) => { event.preventDefault(); try { await Auth.loginUser({ email: event.target[0].value, password: event.target[1].value }); toast('Signed in'); renderDashboard(); updateCounts(); } catch (error) { toast('Login failed', error.message); } });
    if (signupForm) signupForm.addEventListener('submit', async (event) => { event.preventDefault(); try { await Auth.registerUser({ name: event.target[0].value, email: event.target[1].value, password: event.target[2].value }); toast('Account created'); renderDashboard(); updateCounts(); } catch (error) { toast('Signup failed', error.message); } });
    if (forgotForm) forgotForm.addEventListener('submit', (event) => { event.preventDefault(); toast('Password reset', Auth.forgotPassword(event.target[0].value)); });
    const profileForm = qs('#profileForm');
    if (profileForm && user) profileForm.addEventListener('submit', (event) => { event.preventDefault(); Auth.updateCurrentUser({ name: qs('#profileName').value, email: qs('#profileEmail').value }); toast('Profile updated'); renderDashboard(); });
  }

  function renderTracking() {
    const root = qs('#trackingRoot');
    if (!root) return;
    const params = new URLSearchParams(location.search);
    const orderId = params.get('order');
    const orders = Store.getOrders();
    const order = orders.find((item) => item.id === orderId) || orders[0];
    if (!order) {
      root.innerHTML = '<div class="page-card empty-state">No order found. Place an order to see tracking updates.</div>';
      return;
    }
    const stages = ['Order received', 'Preparing', 'Baking', 'Out for delivery', 'Delivered'];
    const current = Math.max(0, order.statusIndex || 0);
    root.innerHTML = `
      <section class="split-grid align-start">
        <div class="glass panel-soft">
          <p class="eyebrow">Tracking ${escapeHtml(order.id)}</p>
          <h2>${escapeHtml(order.trackingCode)}</h2>
          <div class="stepper">${stages.map((stage, index) => `<div class="step ${index < current ? 'done' : index === current ? 'active' : ''}"><div class="dot"></div><div><strong>${stage}</strong><div class="review-meta">${index === current ? 'Current status' : index < current ? 'Completed' : 'Pending'}</div></div></div>`).join('')}</div>
        </div>
        <div class="glass panel-soft">
          <p class="eyebrow">Order details</p>
          <div class="summary-list"><div><strong>Placed</strong><span>${new Date(order.createdAt).toLocaleString()}</span></div><div><strong>Payment</strong><span>${escapeHtml(order.paymentMethod)}</span></div><div><strong>Total</strong><span>${SD.formatPrice(order.totals.total)}</span></div></div>
          <div class="stack-space">${order.items.map((item) => `<div class="summary-row"><span>${escapeHtml(item.name)} x${item.quantity}</span><strong>${SD.formatPrice(item.price * item.quantity)}</strong></div>`).join('')}</div>
        </div>
      </section>`;
  }

  function renderContact() {
    const form = qs('#contactForm');
    if (form) form.addEventListener('submit', (event) => { event.preventDefault(); toast('Message sent', 'We will reply shortly.'); form.reset(); });
  }

  function renderAbout() {
    const teamRoot = qs('#aboutTeam');
    if (teamRoot) teamRoot.innerHTML = SD.team.map((item) => `<article class="team-card"><div class="product-media"><img src="${item.image}" alt="${escapeHtml(item.name)}" loading="lazy"></div><div class="team-body"><strong>${escapeHtml(item.name)}</strong><div class="review-meta">${escapeHtml(item.role)}</div></div></article>`).join('');
  }

  function renderLoginSignupForm() {
    const form = qs('#authForm');
    if (!form) return;
    form.addEventListener('submit', async (event) => {
      event.preventDefault();
      try {
        if (state.mode === 'signup') {
          await Auth.registerUser({ name: qs('#authName')?.value || 'Guest', email: qs('#authEmail').value, password: qs('#authPassword').value });
          toast('Account created');
        } else {
          await Auth.loginUser({ email: qs('#authEmail').value, password: qs('#authPassword').value });
          toast('Signed in');
        }
        location.href = 'dashboard.html';
      } catch (error) {
        toast('Authentication failed', error.message);
      }
    });
  }

  function renderAdmin() {
    const root = qs('#adminRoot');
    if (!root) return;
    const products = SD.products;
    const orders = Store.getOrders();
    const users = JSON.parse(localStorage.getItem('sweet_delights_users') || '[]');
    const wishlist = Store.getWishlist();
    const reviews = SD.products.flatMap((product) => product.reviewsData.map((review) => ({ ...review, product: product.name })));
    const coupons = Object.entries(Store.coupons);
    const revenue = orders.reduce((sum, order) => sum + (order.totals?.total || 0), 0);
    root.innerHTML = `
      <section class="admin-grid">
        <div class="glass panel-soft">
          <div class="dashboard-toolbar">
            <div class="metric-card"><div class="metric-body"><div class="review-meta">Revenue</div><strong>${SD.formatPrice(revenue)}</strong></div></div>
            <div class="metric-card"><div class="metric-body"><div class="review-meta">Orders</div><strong>${orders.length}</strong></div></div>
            <div class="metric-card"><div class="metric-body"><div class="review-meta">Customers</div><strong>${users.length}</strong></div></div>
            <div class="metric-card"><div class="metric-body"><div class="review-meta">Wishlist items</div><strong>${wishlist.length}</strong></div></div>
          </div>
          <h2>Sales analytics</h2>
          <div class="chart-bars">${[38, 52, 61, 48, 74, 68].map((value, index) => `<div><div class="summary-row"><span>Month ${index + 1}</span><span>${value}%</span></div><div class="chart-bar" style="width:${value}%"></div></div>`).join('')}</div>
        </div>
        <div class="glass panel-soft">
          <h2>Product management</h2>
          <div class="stack-form"><input placeholder="New product name"><div class="two-col"><input placeholder="Category"><input placeholder="Price"></div><button class="btn btn-secondary" type="button">Add product</button></div>
          <div class="table-wrap"><table><thead><tr><th>Product</th><th>Category</th><th>Price</th><th>Actions</th></tr></thead><tbody>${products.map((product) => `<tr><td>${escapeHtml(product.name)}</td><td>${escapeHtml(product.category)}</td><td>${SD.formatPrice(product.price)}</td><td><button class="table-btn">Edit</button> <button class="table-btn">Archive</button></td></tr>`).join('')}</tbody></table></div>
        </div>
      </section>
      <section class="section-gap split-grid align-start">
        <div class="glass panel-soft"><h2>Orders</h2><div class="table-wrap"><table><thead><tr><th>ID</th><th>Status</th><th>Total</th></tr></thead><tbody>${orders.map((order) => `<tr><td>${order.id}</td><td><select class="status-select" data-order-id="${order.id}"><option ${order.status === 'received' ? 'selected' : ''}>received</option><option ${order.status === 'preparing' ? 'selected' : ''}>preparing</option><option ${order.status === 'baking' ? 'selected' : ''}>baking</option><option ${order.status === 'out_for_delivery' ? 'selected' : ''}>out_for_delivery</option><option ${order.status === 'delivered' ? 'selected' : ''}>delivered</option></select></td><td>${SD.formatPrice(order.totals.total)}</td></tr>`).join('') || '<tr><td colspan="3">No orders yet.</td></tr>'}</tbody></table></div></div>
        <div class="glass panel-soft"><h2>Customers and reviews</h2><div class="table-wrap"><table><thead><tr><th>Name</th><th>Email</th></tr></thead><tbody>${users.map((user) => `<tr><td>${escapeHtml(user.name)}</td><td>${escapeHtml(user.email)}</td></tr>`).join('') || '<tr><td colspan="2">No customers found.</td></tr>'}</tbody></table></div><div class="section-gap"><h3>Coupons</h3><div class="table-wrap"><table><thead><tr><th>Code</th><th>Discount</th></tr></thead><tbody>${coupons.map(([code, data]) => `<tr><td>${code}</td><td>${data.label}</td></tr>`).join('')}</tbody></table></div></div><div class="section-gap"><h3>Reviews</h3><div class="stack-space">${reviews.slice(0, 6).map((review) => `<article class="review-card"><div class="review-body"><strong>${escapeHtml(review.product)} - ${escapeHtml(review.name)}</strong><div class="review-meta">${review.rating.toFixed(1)}/5</div><p class="review-copy">${escapeHtml(review.copy)}</p></div></article>`).join('')}</div></div></div>
      </section>`;
    qsa('.status-select', root).forEach((select) => {
      select.addEventListener('change', () => {
        const nextStatus = select.value;
        const updatedOrders = Store.getOrders().map((order) => (
          order.id === select.dataset.orderId
            ? { ...order, status: nextStatus, statusIndex: ['received', 'preparing', 'baking', 'out_for_delivery', 'delivered'].indexOf(nextStatus) }
            : order
        ));
        Store.setOrders(updatedOrders);
        toast('Order updated', `${select.dataset.orderId} is now ${nextStatus}`);
      });
    });
  }

  function initForms() {
    qsa('form#footerNewsletter').forEach((form) => form.addEventListener('submit', handleNewsletter));
    renderContact();
    renderLoginSignupForm();
  }

  function initPage() {
    renderHeader();
    renderFooter();
    renderChatWidget();
    initTheme();
    initMenu();
    setActiveNav();
    bindPageTransitions();
    bindActionClicks();
    updateCounts();
    initForms();
    if (state.page === 'home') renderHome();
    if (state.page === 'catalog') renderCatalog();
    if (state.page === 'detail') renderDetail();
    if (state.page === 'customize') renderCustomization();
    if (state.page === 'cart') renderCart();
    if (state.page === 'checkout') renderCheckout();
    if (state.page === 'dashboard') renderDashboard();
    if (state.page === 'tracking') renderTracking();
    if (state.page === 'about') renderAbout();
    if (state.page === 'contact') renderContact();
    if (state.page === 'admin') renderAdmin();
  }

  document.addEventListener('DOMContentLoaded', () => {
    Auth.ensureDemoUser().finally(() => {
      initPage();
      document.body.classList.add('page-enter');
      setTimeout(() => setLoader(false), 450);
    });
  });

  window.addEventListener('beforeunload', () => setLoader(true));
})();
