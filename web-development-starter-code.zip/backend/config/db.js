const mongoose = require('mongoose');

async function connectDB(uri) {
  if (!uri) {
    throw new Error('MONGO_URI is required');
  }
  mongoose.set('strictQuery', true);
  return mongoose.connect(uri);
}

module.exports = connectDB;
