require('dotenv').config();

const app = require('./app');
const connectDB = require('./config/db');
const { seedDatabase } = require('./seed');

const port = process.env.PORT || 4000;

async function start() {
  try {
    await connectDB(process.env.MONGO_URI);
    await seedDatabase();
    console.log('MongoDB connected and sample data seeded');
  } catch (error) {
    console.warn('MongoDB unavailable, starting web app in static/demo mode.');
  }

  app.listen(port, () => {
    console.log(`Sweet Delights running at http://localhost:${port}`);
  });
}

start();
