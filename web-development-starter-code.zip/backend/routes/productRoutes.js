const express = require('express');
const Product = require('../models/Product');

const router = express.Router();

router.get('/', async (req, res, next) => {
  try {
    const { q = '', category = 'All', sort = 'featured' } = req.query;
    const query = {};
    if (category && category !== 'All') query.category = category;
    if (q) query.$or = [
      { name: new RegExp(q, 'i') },
      { description: new RegExp(q, 'i') },
      { tags: new RegExp(q, 'i') }
    ];
    let items = await Product.find(query);
    if (sort === 'price-asc') items.sort((a, b) => a.price - b.price);
    else if (sort === 'price-desc') items.sort((a, b) => b.price - a.price);
    else if (sort === 'rating-desc') items.sort((a, b) => b.rating - a.rating);
    else items.sort((a, b) => Number(b.featured) - Number(a.featured) || Number(b.bestseller) - Number(a.bestseller));
    res.json({ items });
  } catch (error) {
    next(error);
  }
});

router.get('/featured', async (req, res, next) => {
  try {
    const items = await Product.find({ featured: true }).sort({ updatedAt: -1 }).limit(8);
    res.json({ items });
  } catch (error) {
    next(error);
  }
});

router.get('/:slug/recommendations', async (req, res, next) => {
  try {
    const product = await Product.findOne({ slug: req.params.slug });
    if (!product) return res.status(404).json({ message: 'Product not found' });
    const items = await Product.find({ slug: { $ne: product.slug }, category: product.category }).limit(4);
    res.json({ items });
  } catch (error) {
    next(error);
  }
});

router.get('/:slug', async (req, res, next) => {
  try {
    const product = await Product.findOne({ slug: req.params.slug });
    if (!product) return res.status(404).json({ message: 'Product not found' });
    res.json({ product });
  } catch (error) {
    next(error);
  }
});

module.exports = router;
