const express = require('express');
const Order = require('../models/Order');
const { protect } = require('../middleware/auth');

const router = express.Router();

router.post('/', async (req, res, next) => {
  try {
    const payload = req.body || {};
    if (!payload.items || !payload.items.length) return res.status(400).json({ message: 'No order items found' });
    const orderNumber = `SD-${Date.now().toString(36).toUpperCase()}`;
    const trackingCode = `TRK-${Math.random().toString(36).slice(2, 8).toUpperCase()}`;
    const order = await Order.create({ ...payload, orderNumber, trackingCode, timeline: [{ status: 'received', at: new Date() }] });
    res.status(201).json({ order });
  } catch (error) {
    next(error);
  }
});

router.get('/track/:id', async (req, res, next) => {
  try {
    const order = await Order.findOne({ orderNumber: req.params.id });
    if (!order) return res.status(404).json({ message: 'Order not found' });
    res.json({ order });
  } catch (error) {
    next(error);
  }
});

router.get('/me/history', protect, async (req, res, next) => {
  try {
    const orders = await Order.find({ user: req.user._id }).sort({ createdAt: -1 });
    res.json({ orders });
  } catch (error) {
    next(error);
  }
});

module.exports = router;
