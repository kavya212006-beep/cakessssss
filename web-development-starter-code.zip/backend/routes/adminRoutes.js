const express = require('express');
const Product = require('../models/Product');
const Order = require('../models/Order');
const User = require('../models/User');
const Coupon = require('../models/Coupon');
const Review = require('../models/Review');
const { protect, requireRole } = require('../middleware/auth');

const router = express.Router();

router.get('/summary', protect, requireRole('admin'), async (req, res, next) => {
  try {
    const [products, orders, customers, coupons, reviews] = await Promise.all([
      Product.countDocuments(),
      Order.find(),
      User.countDocuments({ role: 'customer' }),
      Coupon.countDocuments(),
      Review.countDocuments()
    ]);
    const revenue = orders.reduce((sum, order) => sum + (order.total || 0), 0);
    res.json({ products, orders: orders.length, customers, coupons, reviews, revenue });
  } catch (error) {
    next(error);
  }
});

router.get('/products', protect, requireRole('admin'), async (req, res, next) => {
  try {
    res.json({ items: await Product.find().sort({ createdAt: -1 }) });
  } catch (error) {
    next(error);
  }
});

router.patch('/products/:id', protect, requireRole('admin'), async (req, res, next) => {
  try {
    const product = await Product.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json({ product });
  } catch (error) {
    next(error);
  }
});

router.delete('/products/:id', protect, requireRole('admin'), async (req, res, next) => {
  try {
    await Product.findByIdAndDelete(req.params.id);
    res.json({ message: 'Product removed' });
  } catch (error) {
    next(error);
  }
});

router.get('/orders', protect, requireRole('admin'), async (req, res, next) => {
  try {
    res.json({ items: await Order.find().sort({ createdAt: -1 }) });
  } catch (error) {
    next(error);
  }
});

router.patch('/orders/:id/status', protect, requireRole('admin'), async (req, res, next) => {
  try {
    const order = await Order.findByIdAndUpdate(req.params.id, { status: req.body.status, statusIndex: req.body.statusIndex }, { new: true });
    res.json({ order });
  } catch (error) {
    next(error);
  }
});

router.get('/customers', protect, requireRole('admin'), async (req, res, next) => {
  try {
    res.json({ items: await User.find().select('-passwordHash').sort({ createdAt: -1 }) });
  } catch (error) {
    next(error);
  }
});

router.get('/coupons', protect, requireRole('admin'), async (req, res, next) => {
  try {
    res.json({ items: await Coupon.find().sort({ createdAt: -1 }) });
  } catch (error) {
    next(error);
  }
});

router.get('/reviews', protect, requireRole('admin'), async (req, res, next) => {
  try {
    res.json({ items: await Review.find().sort({ createdAt: -1 }) });
  } catch (error) {
    next(error);
  }
});

module.exports = router;
