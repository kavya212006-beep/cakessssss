const express = require('express');
const nodemailer = require('nodemailer');

const router = express.Router();

async function sendMail(subject, text) {
  if (!process.env.SMTP_HOST || !process.env.SMTP_USER || !process.env.SMTP_PASS) {
    return null;
  }
  const transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT || 587),
    secure: Number(process.env.SMTP_PORT || 587) === 465,
    auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
  });
  return transporter.sendMail({ from: process.env.FROM_EMAIL || process.env.SMTP_USER, to: process.env.FROM_EMAIL || process.env.SMTP_USER, subject, text });
}

router.post('/contact', async (req, res, next) => {
  try {
    await sendMail(`Contact form: ${req.body.subject || 'Sweet Delights'}`, `${req.body.name}\n${req.body.email}\n\n${req.body.message}`);
    res.json({ message: 'Contact request sent' });
  } catch (error) {
    next(error);
  }
});

router.post('/newsletter', async (req, res, next) => {
  try {
    await sendMail('Newsletter subscription', req.body.email || 'New subscription');
    res.json({ message: 'Subscription saved' });
  } catch (error) {
    next(error);
  }
});

module.exports = router;
