const express = require('express');
const Stripe = require('stripe');
const Razorpay = require('razorpay');

const router = express.Router();

router.post('/stripe/create-intent', async (req, res, next) => {
  try {
    const amount = Math.round(Number(req.body.amount || 0) * 100);
    if (!process.env.STRIPE_SECRET_KEY) {
      return res.json({ demo: true, clientSecret: `demo_secret_${amount}` });
    }
    const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
    const intent = await stripe.paymentIntents.create({ amount, currency: 'usd', automatic_payment_methods: { enabled: true } });
    res.json({ clientSecret: intent.client_secret });
  } catch (error) {
    next(error);
  }
});

router.post('/razorpay/create-order', async (req, res, next) => {
  try {
    const amount = Math.round(Number(req.body.amount || 0) * 100);
    if (!process.env.RAZORPAY_KEY_ID || !process.env.RAZORPAY_KEY_SECRET) {
      return res.json({ demo: true, orderId: `demo_${Date.now()}`, amount });
    }
    const razorpay = new Razorpay({ key_id: process.env.RAZORPAY_KEY_ID, key_secret: process.env.RAZORPAY_KEY_SECRET });
    const order = await razorpay.orders.create({ amount, currency: 'INR', receipt: `rcpt_${Date.now()}` });
    res.json({ order });
  } catch (error) {
    next(error);
  }
});

module.exports = router;
