const mongoose = require('mongoose');

const orderSchema = new mongoose.Schema({
  orderNumber: { type: String, required: true, unique: true },
  trackingCode: { type: String, required: true },
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  items: [{
    slug: String,
    name: String,
    price: Number,
    quantity: Number,
    options: mongoose.Schema.Types.Mixed
  }],
  customer: {
    name: String,
    email: String,
    phone: String
  },
  shippingAddress: String,
  paymentMethod: String,
  subtotal: Number,
  discount: Number,
  delivery: Number,
  tax: Number,
  total: Number,
  status: { type: String, default: 'received' },
  statusIndex: { type: Number, default: 0 },
  timeline: [{ status: String, at: Date }]
}, { timestamps: true });

module.exports = mongoose.model('Order', orderSchema);
