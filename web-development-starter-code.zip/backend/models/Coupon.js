const mongoose = require('mongoose');

const couponSchema = new mongoose.Schema({
  code: { type: String, required: true, unique: true, uppercase: true },
  label: { type: String, required: true },
  discount: { type: Number, required: true },
  active: { type: Boolean, default: true },
  usageLimit: { type: Number, default: null }
}, { timestamps: true });

module.exports = mongoose.model('Coupon', couponSchema);
