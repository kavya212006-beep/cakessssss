const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
  slug: { type: String, required: true, unique: true, index: true },
  name: { type: String, required: true },
  category: { type: String, required: true },
  price: { type: Number, required: true },
  rating: { type: Number, default: 4.8 },
  reviews: { type: Number, default: 0 },
  featured: { type: Boolean, default: false },
  bestseller: { type: Boolean, default: false },
  badge: { type: String, default: '' },
  availability: { type: String, default: 'In stock' },
  delivery: { type: String, default: 'Next day' },
  description: { type: String, required: true },
  images: [{ type: String }],
  flavors: [{ type: String }],
  sizes: [{ type: String }],
  weights: [{ type: String }],
  tags: [{ type: String }],
  inventory: { type: Number, default: 25 }
}, { timestamps: true });

module.exports = mongoose.model('Product', productSchema);
