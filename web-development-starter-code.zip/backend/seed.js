require('dotenv').config();

const bcrypt = require('bcryptjs');
const connectDB = require('./config/db');
const User = require('./models/User');
const Product = require('./models/Product');
const Order = require('./models/Order');
const Coupon = require('./models/Coupon');
const Review = require('./models/Review');

const products = [
  { slug: 'velvet-rose-birthday', name: 'Velvet Rose Birthday Cake', category: 'Birthday Cakes', price: 78, rating: 4.9, reviews: 128, featured: true, bestseller: true, badge: 'Signature', availability: 'In stock', delivery: 'Same day', description: 'A premium red velvet birthday cake finished with silky buttercream roses and a champagne-gold accent.', images: ['https://images.unsplash.com/photo-1551024601-bec78aea704b?auto=format&fit=crop&w=1200&q=80'], flavors: ['Red velvet', 'Vanilla bean', 'Chocolate'], sizes: ['6 in', '8 in', '10 in'], weights: ['1 kg', '1.5 kg', '2 kg'], tags: ['birthday', 'romantic', 'fresh cream'], inventory: 22 },
  { slug: 'celestial-white-wedding', name: 'Celestial White Wedding Cake', category: 'Wedding Cakes', price: 164, rating: 5.0, reviews: 94, featured: true, bestseller: true, badge: 'Luxury', availability: 'Pre-order', delivery: '2 days', description: 'A towering white wedding cake with sugar florals, pearl detailing, and a refined, modern silhouette.', images: ['https://images.unsplash.com/photo-1464349095431-e9a21285b5f3?auto=format&fit=crop&w=1200&q=80'], flavors: ['Vanilla bean', 'Almond cream', 'Pistachio'], sizes: ['8 in', '10 in', '12 in'], weights: ['2 kg', '3 kg', '4 kg'], tags: ['wedding', 'luxury', 'tiered'], inventory: 12 },
  { slug: 'amber-anniversary-celebration', name: 'Amber Anniversary Celebration', category: 'Anniversary Cakes', price: 96, rating: 4.8, reviews: 76, featured: true, bestseller: false, badge: 'Elegant', availability: 'In stock', delivery: 'Next day', description: 'A warm caramel-toned anniversary cake with gold leaf edges and a silky vanilla bean filling.', images: ['https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=1200&q=80'], flavors: ['Caramel', 'Vanilla bean', 'Hazelnut'], sizes: ['6 in', '8 in', '10 in'], weights: ['1 kg', '1.5 kg', '2 kg'], tags: ['anniversary', 'gold leaf', 'caramel'], inventory: 18 },
  { slug: 'mirror-glaze-designer', name: 'Mirror Glaze Designer Cake', category: 'Designer Cakes', price: 112, rating: 4.9, reviews: 105, featured: false, bestseller: true, badge: 'Designer', availability: 'In stock', delivery: 'Next day', description: 'A sleek mirror-glaze creation with artistic color bands and a glossy finish for modern celebrations.', images: ['https://images.unsplash.com/photo-1486427944299-d1955d23e34d?auto=format&fit=crop&w=1200&q=80'], flavors: ['Berry mousse', 'Dark chocolate', 'Pistachio'], sizes: ['6 in', '8 in', '10 in'], weights: ['1 kg', '1.5 kg', '2 kg'], tags: ['designer', 'mirror glaze', 'modern'], inventory: 16 },
  { slug: 'belgian-truffle-chocolate', name: 'Belgian Truffle Chocolate Cake', category: 'Chocolate Cakes', price: 84, rating: 4.9, reviews: 143, featured: true, bestseller: true, badge: 'Best Seller', availability: 'In stock', delivery: 'Same day', description: 'Deep cocoa sponge layered with Belgian truffle cream and a glossy ganache finish.', images: ['https://images.unsplash.com/photo-1602351447937-745cb720612f?auto=format&fit=crop&w=1200&q=80'], flavors: ['Dark chocolate', 'Mocha', 'Nutella'], sizes: ['6 in', '8 in', '10 in'], weights: ['1 kg', '1.5 kg', '2 kg'], tags: ['chocolate', 'truffle', 'ganache'], inventory: 24 }
];

async function seedDatabase() {
  if (await Product.countDocuments()) return;

  const passwordHash = await bcrypt.hash('Sweet123!', 12);
  const adminHash = await bcrypt.hash('Admin123!', 12);

  await Promise.all([
    Product.insertMany(products),
    User.insertMany([
      { name: 'Sophia Bennett', email: 'sophia@sweetdelights.com', passwordHash, role: 'customer', addresses: ['88 Velvet Avenue, New York'], wishlist: [] },
      { name: 'Admin Delight', email: 'admin@sweetdelights.com', passwordHash: adminHash, role: 'admin', addresses: [], wishlist: [] }
    ]),
    Coupon.insertMany([
      { code: 'SWEET15', label: '15% off', discount: 0.15, active: true },
      { code: 'SWEET10', label: '10% off', discount: 0.1, active: true },
      { code: 'DELIGHT20', label: '20% off', discount: 0.2, active: true }
    ]),
    Review.insertMany([
      { productSlug: 'velvet-rose-birthday', userName: 'Mia', rating: 5, comment: 'Elegant and unforgettable.' },
      { productSlug: 'belgian-truffle-chocolate', userName: 'Ethan', rating: 5, comment: 'Deep chocolate perfection.' }
    ])
  ]);

  await Order.insertMany([
    {
      orderNumber: 'SD-DEMO1',
      trackingCode: 'TRK-DEMO1',
      customer: { name: 'Sophia Bennett', email: 'sophia@sweetdelights.com', phone: '555-240-2025' },
      shippingAddress: '88 Velvet Avenue, New York',
      paymentMethod: 'stripe',
      items: [{ slug: 'velvet-rose-birthday', name: 'Velvet Rose Birthday Cake', price: 78, quantity: 1 }],
      subtotal: 78,
      discount: 0,
      delivery: 12,
      tax: 7.65,
      total: 97.65,
      status: 'preparing',
      statusIndex: 1,
      timeline: [{ status: 'received', at: new Date() }, { status: 'preparing', at: new Date() }]
    }
  ]);
}

async function run() {
  await connectDB(process.env.MONGO_URI);
  await seedDatabase();
  console.log('Database seeded');
  process.exit(0);
}

if (require.main === module) {
  run().catch((error) => {
    console.error(error);
    process.exit(1);
  });
}

module.exports = { seedDatabase };
