# Sweet Delights

Sweet Delights is a premium, fully responsive cake shop experience with a polished multi-page frontend and a Node.js/Express/MongoDB backend.

## What is included

- Home, catalog, product detail, customization, cart, checkout, tracking, account, about, contact, and admin pages
- Luxury UI with dark and light mode, glassmorphism, motion, and responsive layouts
- Local demo flows for cart, wishlist, recent views, account management, and order tracking
- Backend API with JWT auth, MongoDB models, order and product routes, contact/newsletter endpoints, and payment stubs for Stripe and Razorpay

## Demo account

- Email: sophia@sweetdelights.com
- Password: Sweet123!

## Admin demo account

- Email: admin@sweetdelights.com
- Password: Admin123!

## Setup

1. Install dependencies
   - `npm install`
2. Create your environment file
   - Copy `.env.example` to `.env`
3. Start MongoDB locally or update `MONGO_URI`
4. Seed sample data
   - `npm run seed`
5. Start the app
   - `npm run dev`
6. Open `http://localhost:4000`

## Project structure

- `index.html`, `products.html`, `product-details.html`, `customize.html`, `cart.html`, `checkout.html`, `dashboard.html`, `tracking.html`, `about.html`, `contact.html`, `login.html`, `signup.html`, `admin.html`
- `css/` for shared styling, responsive rules, and animations
- `js/` for products, cart, auth, and app logic
- `backend/` for API, models, middleware, routes, and seed data

## Payment notes

- Stripe and Razorpay routes return demo responses when keys are not configured.
- Add valid keys in `.env` to enable live payment creation.

## Deployment

- Host the frontend and backend together with the Express app, or serve the frontend statically and deploy the API separately.
- For production, set strong secrets, configure MongoDB Atlas, and add live payment keys.
